        		
        	</div><!-- /content -->


        	<?php
	            /**
	             * woocommerce_sidebar hook
	             *
	             * @hooked woocommerce_get_sidebar - 10
	             */
	            do_action( 'woocommerce_sidebar' );

	        ?>

        	<div class="clearfix"></div>
        </div><!-- /content_background -->
    </section><!-- /main -->
	<div class="clearfix"></div>
</div><!-- /#container -->